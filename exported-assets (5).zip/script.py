
# Create the admin.css file with all styles
admin_css = '''/* ============================================
   ADMIN CASAS - ESTILOS PROFESIONALES
   ============================================ */

:root {
    --primary: #0b5482;
    --secondary: #4fd1c5;
    --accent: #ffd166;
    --dark: #072d4b;
    --light: #e9f7f6;
    --danger: #f14b4b;
    --warning: #ffd166;
    --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
    --shadow-md: 0 4px 12px rgba(0,0,0,0.12);
    --shadow-lg: 0 8px 25px rgba(0,0,0,0.15);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* ============================================
   NAVBAR
   ============================================ */

.navbar {
    background: linear-gradient(90deg, var(--dark) 0%, var(--primary) 100%);
    box-shadow: var(--shadow-md);
}

.navbar-brand {
    font-weight: 700;
    font-size: 1.5rem;
    color: var(--accent) !important;
    letter-spacing: 0.5px;
}

/* ============================================
   STATS CARDS
   ============================================ */

.stats-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
    max-width: 900px;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: var(--shadow-sm);
    border-left: 5px solid;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 100px;
    height: 100px;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
    border-radius: 50%;
    transform: translate(30px, -30px);
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-lg);
}

.stat-card.total {
    border-left-color: var(--primary);
}

.stat-card.vip {
    border-left-color: var(--accent);
}

.stat-card.precio {
    border-left-color: var(--secondary);
}

.stat-card h3 {
    font-size: 2rem;
    font-weight: 700;
    color: var(--primary);
    margin-bottom: 0.5rem;
    position: relative;
    z-index: 1;
}

.stat-card p {
    color: #6c757d;
    font-weight: 500;
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
}

.stat-icon {
    font-size: 2rem;
    position: absolute;
    top: 1rem;
    right: 1.5rem;
    opacity: 0.1;
    z-index: 0;
}

/* ============================================
   FILTROS
   ============================================ */

.filters-card {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: var(--shadow-sm);
    margin-bottom: 2rem;
}

.filters-card .form-label {
    font-weight: 600;
    color: var(--dark);
    font-size: 0.85rem;
    margin-bottom: 0.5rem;
}

.filters-card .form-control,
.filters-card .form-select {
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 0.65rem 0.75rem;
    transition: border-color 0.3s;
    font-size: 0.9rem;
}

.filters-card .form-control:focus,
.filters-card .form-select:focus {
    border-color: var(--secondary);
    box-shadow: 0 0 0 0.2rem rgba(79, 209, 197, 0.15);
}

/* ============================================
   MODAL
   ============================================ */

.modal-header {
    background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    border: none;
}

.modal-header .btn-close {
    filter: brightness(0) invert(1);
}

.modal-title {
    font-weight: 700;
    letter-spacing: 0.5px;
}

.modal-body {
    padding: 2rem;
    max-height: 85vh;
    overflow-y: auto;
}

.modal-body::-webkit-scrollbar {
    width: 8px;
}

.modal-body::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.modal-body::-webkit-scrollbar-thumb {
    background: var(--secondary);
    border-radius: 10px;
}

.modal-body::-webkit-scrollbar-thumb:hover {
    background: var(--primary);
}

/* ============================================
   FORMULARIO
   ============================================ */

.form-label {
    font-weight: 600;
    color: var(--dark);
    font-size: 0.9rem;
    margin-bottom: 0.5rem;
}

.form-control,
.form-select {
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 0.65rem 0.75rem;
    transition: border-color 0.3s;
}

.form-control:focus,
.form-select:focus {
    border-color: var(--secondary);
    box-shadow: 0 0 0 0.2rem rgba(79, 209, 197, 0.15);
}

.form-check-input {
    width: 1.25em;
    height: 1.25em;
    border: 2px solid #dee2e6;
    border-radius: 4px;
    transition: all 0.3s;
}

.form-check-input:checked {
    background-color: var(--secondary);
    border-color: var(--secondary);
}

.form-check-input:focus {
    border-color: var(--secondary);
    box-shadow: 0 0 0 0.25rem rgba(79, 209, 197, 0.25);
}

.form-check-label {
    padding-left: 0.5rem;
    color: var(--dark);
    font-weight: 500;
    cursor: pointer;
}

h6 {
    font-weight: 700;
    color: var(--primary);
    text-transform: uppercase;
    font-size: 0.85rem;
    letter-spacing: 0.5px;
    margin-top: 1.5rem;
    margin-bottom: 0.75rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

/* ============================================
   BOTONES
   ============================================ */

.btn-primary {
    background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 100%);
    border: none;
    font-weight: 600;
    transition: all 0.3s;
}

.btn-primary:hover {
    background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 100%);
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(11, 84, 130, 0.3);
}

.btn-secondary {
    background: #6c757d;
    border: none;
    font-weight: 600;
}

.btn-secondary:hover {
    background: #5a6268;
    transform: translateY(-2px);
}

.btn-warning {
    background: var(--accent);
    color: var(--dark);
    border: none;
    font-weight: 600;
}

.btn-warning:hover {
    background: #ffb84d;
    color: var(--dark);
}

.btn-info {
    background: var(--secondary);
    border: none;
    color: white;
    font-weight: 600;
}

.btn-info:hover {
    background: #3fbdb1;
    transform: translateY(-2px);
}

.btn-danger {
    background: var(--danger);
    border: none;
    font-weight: 600;
}

.btn-danger:hover {
    background: #d63838;
}

.btn-sm {
    padding: 0.35rem 0.65rem;
    font-size: 0.85rem;
}

.btn-lg {
    padding: 0.75rem 1.5rem;
    font-size: 1rem;
}

.btn-action {
    padding: 0.4rem 0.8rem;
    font-size: 0.8rem;
    margin: 0.2rem;
}

/* ============================================
   ALERTAS
   ============================================ */

.alert {
    border: none;
    border-radius: 8px;
    border-left: 4px solid;
}

.alert-success {
    background-color: #f0fdf4;
    border-left-color: #22c55e;
    color: #155724;
}

.alert-danger {
    background-color: #fff5f5;
    border-left-color: var(--danger);
    color: #721c24;
}

.alert-info {
    background-color: #f0f9ff;
    border-left-color: var(--secondary);
    color: #0c5460;
}

/* ============================================
   TABLA
   ============================================ */

.table-responsive {
    border-radius: 12px;
    overflow: hidden;
    box-shadow: var(--shadow-sm);
}

.table {
    background: white;
    margin-bottom: 0;
}

.table thead {
    background: linear-gradient(90deg, var(--dark) 0%, var(--primary) 100%);
    color: white;
}

.table thead th {
    border: none;
    font-weight: 600;
    padding: 1rem 0.75rem;
}

.table tbody tr {
    transition: background-color 0.2s;
    border-bottom: 1px solid #e9ecef;
}

.table tbody tr:hover {
    background-color: #f8f9ff;
}

.table tbody td {
    padding: 0.9rem 0.75rem;
    vertical-align: middle;
}

.table img {
    border-radius: 6px;
    border: 2px solid #e9ecef;
    transition: transform 0.2s;
}

.table img:hover {
    transform: scale(1.05);
}

/* ============================================
   BADGES
   ============================================ */

.badge {
    font-size: 0.75rem;
    padding: 0.35rem 0.65rem;
    border-radius: 4px;
}

.badge-secondary {
    background: #6c757d;
}

.badge-vip {
    background: linear-gradient(135deg, var(--accent) 0%, #ffb84d 100%);
    color: var(--dark);
    font-weight: 600;
}

.badge-accesible {
    background: linear-gradient(135deg, var(--secondary) 0%, #3fbdb1 100%);
    color: white;
    font-weight: 600;
}

/* ============================================
   SECCIONES
   ============================================ */

.section-title {
    margin-top: 2rem;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 3px solid var(--secondary);
    font-weight: 700;
    color: var(--dark);
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 1.5rem;
}

.container-fluid {
    padding-top: 2rem;
    padding-bottom: 2rem;
}

/* ============================================
   PAGINACIÓN
   ============================================ */

.pagination {
    margin-top: 2rem;
    justify-content: center;
}

.pagination .page-link {
    color: var(--primary);
    border: 2px solid #e9ecef;
    border-radius: 8px;
    margin: 0 0.25rem;
    transition: all 0.3s;
}

.pagination .page-link:hover {
    background-color: var(--secondary);
    color: white;
    border-color: var(--secondary);
}

.pagination .page-item.active .page-link {
    background-color: var(--primary);
    border-color: var(--primary);
}

/* ============================================
   RESPONSIVE
   ============================================ */

@media (max-width: 768px) {
    .stats-container {
        grid-template-columns: 1fr;
    }

    .stat-card h3 {
        font-size: 1.5rem;
    }

    .stat-card p {
        font-size: 0.8rem;
    }

    .modal-body {
        max-height: 90vh;
        padding: 1rem;
    }

    .btn-action {
        padding: 0.3rem 0.5rem;
        font-size: 0.7rem;
        margin: 0.1rem;
    }

    .table {
        font-size: 0.85rem;
    }

    .table img {
        width: 35px !important;
        height: 35px !important;
    }
}

@media (max-width: 480px) {
    .navbar-brand {
        font-size: 1.2rem;
    }

    .stat-card {
        padding: 1rem;
    }

    .stat-card h3 {
        font-size: 1.2rem;
    }

    .btn-lg {
        font-size: 0.9rem;
        padding: 0.6rem 1rem;
    }
}

/* ============================================
   SCROLL PERSONALIZADO
   ============================================ */

::-webkit-scrollbar {
    width: 10px;
}

::-webkit-scrollbar-track {
    background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
    background: var(--secondary);
    border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
    background: var(--primary);
}
'''

with open('admin.css', 'w', encoding='utf-8') as f:
    f.write(admin_css)

print("✅ ARCHIVO CREADO: admin.css")
print("\n" + "="*80)
