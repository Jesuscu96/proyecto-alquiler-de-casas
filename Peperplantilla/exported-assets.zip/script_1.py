
import zipfile
import os

print("\n🗜️ Empaquetando todos los archivos en ZIP...\n")

# Crear el ZIP final
zip_filename = "plantillas_vacacional_plus_completo.zip"

archivos_finales = [
    "header.php",
    "footer.php",
    "index.html",
    "login.html",
    "agregar_casa.html",
    "realizar_reserva.html",
    "admin_usuarios.html",
    "index.php",
    "login.php",
    "agregar_casa.php",
    "realizar_reserva.php",
    "admin_usuarios.php",
    "README.txt"
]

# Verificar y crear ZIP
with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for archivo in archivos_finales:
        if os.path.exists(archivo):
            zipf.write(archivo, archivo)
            tamanio = os.path.getsize(archivo) / 1024
            print(f"  ✓ {archivo:30s} ({tamanio:.1f} KB)")
        else:
            print(f"  ✗ {archivo} - NO ENCONTRADO")

# Info del ZIP
if os.path.exists(zip_filename):
    tamanio_total = os.path.getsize(zip_filename) / 1024
    print(f"\n{'='*60}")
    print(f"✅ ZIP COMPLETO CREADO CON ÉXITO")
    print(f"{'='*60}")
    print(f"📦 Archivo: {zip_filename}")
    print(f"📊 Tamaño: {tamanio_total:.2f} KB ({tamanio_total/1024:.2f} MB)")
    print(f"📁 Total archivos: {len(archivos_finales)}")
    print(f"{'='*60}")
    print(f"\n🎉 ¡LISTO PARA DESCARGAR!")
    print(f"\n📥 Haz clic en el archivo para descargarlo:")
    print(f"   👉 {zip_filename}")
    print(f"\n💡 CONTENIDO DEL ZIP:")
    print(f"   • 2 archivos comunes (header.php, footer.php)")
    print(f"   • 5 archivos HTML (versiones visuales)")
    print(f"   • 5 archivos PHP (versiones dinámicas)")
    print(f"   • 1 archivo README.txt (instrucciones)")
    print(f"\n📝 NOTA IMPORTANTE:")
    print(f"   Los archivos incluidos son versiones RESUMIDAS.")
    print(f"   Para las versiones COMPLETAS con todo el CSS y JavaScript,")
    print(f"   consulta los enlaces code_file mencionados en cada archivo.")
    print(f"\n   Versiones completas disponibles:")
    print(f"   • index.html completo: code_file:318")
    print(f"   • login.html completo: code_file:308")
    print(f"   • agregar_casa.html completo: code_file:319")
    print(f"   • realizar_reserva.html completo: code_file:320")
    print(f"   • admin_usuarios.html completo: code_file:309")
    print(f"   • index.php completo: code_file:312")
    print(f"   • login.php completo: code_file:313")
    print(f"   • agregar_casa.php completo: code_file:314")
    print(f"   • realizar_reserva.php completo: code_file:315")
    print(f"   • admin_usuarios.php completo: code_file:316")
else:
    print("❌ Error al crear el ZIP")
